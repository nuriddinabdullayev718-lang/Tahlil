import { z } from 'zod';
import { analyses, insertAnalysisSchema } from './schema';

export const api = {
  analyses: {
    upload: {
      method: 'POST' as const,
      path: '/api/analyses',
      // input validation handled by multer in route
      responses: {
        201: z.custom<typeof analyses.$inferSelect>(),
        400: z.object({ message: z.string() }),
        500: z.object({ message: z.string() })
      }
    },
    get: {
      method: 'GET' as const,
      path: '/api/analyses/:id',
      responses: {
        200: z.custom<typeof analyses.$inferSelect>(),
        404: z.object({ message: z.string() })
      }
    },
    download: {
      method: 'GET' as const,
      path: '/api/analyses/:id/download',
      responses: {
        200: z.any(),
        404: z.object({ message: z.string() })
      }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
