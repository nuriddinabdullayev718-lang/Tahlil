import { storage } from "./storage";
import { api } from "@shared/routes";
import { createRequire } from "module";
import multer from "multer";
import OpenAI from "openai";
import path from "path";
import * as mammoth from "mammoth";
import { Document, Packer, Paragraph, TextRun } from "docx";
import type { Express } from "express";
import { type Server } from "http";

const require = createRequire(import.meta.url);

// Initialize OpenAI
const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

// Configure Multer
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.post(api.analyses.upload.path, upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "Fayl yuklanmadi" });
      }

      const fileBuffer = req.file.buffer;
      const fileName = req.file.originalname;
      const fileExt = path.extname(fileName).toLowerCase();

      let originalContent = "";

      // Extract text based on file type
      if (fileExt === '.txt') {
        originalContent = fileBuffer.toString('utf-8');
      } else if (fileExt === '.docx') {
        const result = await mammoth.extractRawText({ buffer: fileBuffer });
        originalContent = result.value;
      } else {
        return res.status(400).json({ message: "Faqat DOCX yoki TXT formatlari qabul qilinadi" });
      }

      const trimmedContent = originalContent.trim();
      if (!trimmedContent || trimmedContent.length < 20) {
        return res.status(400).json({ message: "Fayl bo'sh yoki matn o'qib bo'lmadi (kamida 20 ta belgi kerak)" });
      }

      console.log(`Proceeding with AI analysis. Input length: ${trimmedContent.length}`);

      // Process with OpenAI
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { 
            role: "system", 
            content: `Siz professional muharrirsiz. Vazifangiz foydalanuvchi yuborgan matnni o'zgartirmasdan, undagi xatolarni vizual tarzda belgilab qaytarishdir.
            
            QAT'IY QOIDALAR:
            1. Matnni TO'LIQ saqlang. Hech qanday so'z, jumla, qator yoki paragrafni o'chirib tashlamang.
            2. Matnni qayta yozmang, qisqartirmang yoki mazmunini o'zgartirmang.
            3. Faqat xato topilgan joylarni quyidagi formatda belgilang: [[original|suggestion|reason|type]]
               - original: xato so'z yoki ibora (matndan aynan ko'chirib olingan)
               - suggestion: uning to'g'ri varianti
               - reason: nima uchun xatoligi haqida qisqa tushuntirish
               - type: spelling, grammar yoki style
            4. Xato bo'lmagan matn qismlari aynan o'z holicha qolsin.
            5. Kod bloklari, SQL so'rovlari va texnik satrlarni tahlil qilmang, ularni SKIP qiling va o'zgarmagan holda qoldiring.
            6. Natijada siz qaytargan matn uzunligi (belgilar soni) asl matnnikidan faqat qo'shilgan belgilar ([[...]]) hisobiga farq qilishi kerak.`
          },
          { 
            role: "user", 
            content: trimmedContent 
          }
        ],
        temperature: 0,
      });

      const analysisResult = response.choices[0].message.content || "";
      
      // Save to storage
      const analysis = await storage.createAnalysis({
        originalFileName: fileName,
        originalContent: trimmedContent,
        correctedContent: analysisResult, 
      });

      res.status(201).json(analysis);

    } catch (error) {
      console.error('Analysis error:', error);
      res.status(500).json({ message: "Tahlil jarayonida xatolik yuz berdi" });
    }
  });

  app.get('/health', (_req, res) => {
    res.status(200).send("OK");
  });

  app.get(api.analyses.get.path, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const analysis = await storage.getAnalysis(id);
      
      if (!analysis) {
        return res.status(404).json({ message: "Tahlil topilmadi" });
      }

      res.json(analysis);
    } catch (error) {
      res.status(500).json({ message: "Server xatosi" });
    }
  });

  app.get(api.analyses.download.path, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const analysis = await storage.getAnalysis(id);
      
      if (!analysis) {
        return res.status(404).json({ message: "Tahlil topilmadi" });
      }

      const fileExt = path.extname(analysis.originalFileName).toLowerCase();
      
      if (fileExt === '.docx') {
        const parts = analysis.correctedContent.split(/(\[\[.*?\|.*?\|.*?\|.*?\]\])/g);
        const children: TextRun[] = [];
        
        for (const part of parts) {
          if (part.startsWith('[[') && part.endsWith(']]')) {
            const innerContent = part.slice(2, -2);
            const [orig, sugg] = innerContent.split('|');
            children.push(new TextRun({
              text: (orig || "").trim() + " ",
              strike: true,
              color: "FF0000",
            }));
            children.push(new TextRun({
              text: `(${(sugg || "").trim()})`,
              bold: true,
              color: "008000",
            }));
          } else {
            children.push(new TextRun(part));
          }
        }

        const doc = new Document({
          sections: [{
            properties: {},
            children: [new Paragraph({ children })],
          }],
        });

        const buffer = await Packer.toBuffer(doc);
        res.setHeader('Content-Disposition', `attachment; filename="analysis_${id}.docx"`);
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
        return res.send(buffer);
      }

      // Default to TXT with inline markers
      const cleanText = analysis.correctedContent.replace(/\[\[(.*?)\|(.*?)\|.*?\|.*?\]\]/g, '$1 ($2)');
      const filename = `analysis_${id}.txt`;
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('Content-Type', 'text/plain');
      res.send(cleanText);

    } catch (error) {
      console.error('Download error:', error);
      res.status(500).json({ message: "Yuklab olishda xatolik" });
    }
  });

  return httpServer;
}
