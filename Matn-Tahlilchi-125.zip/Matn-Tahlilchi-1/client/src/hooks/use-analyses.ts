import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";

// GET /api/analyses/:id
export function useAnalysis(id: number) {
  return useQuery({
    queryKey: [api.analyses.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.analyses.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      
      if (!res.ok) {
        if (res.status === 404) return null;
        throw new Error("Tahlil natijalarini yuklashda xatolik yuz berdi");
      }
      
      return api.analyses.get.responses[200].parse(await res.json());
    },
    enabled: !!id && !isNaN(id),
  });
}

// POST /api/analyses (Upload)
export function useUploadAnalysis() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('file', file);
      
      const res = await fetch(api.analyses.upload.path, {
        method: api.analyses.upload.method,
        body: formData,
        credentials: "include",
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.message || "Faylni yuklashda xatolik yuz berdi");
      }

      return api.analyses.upload.responses[201].parse(await res.json());
    },
    // We don't invalidate list query because there isn't one yet, 
    // but we return the data to navigate to the result page
  });
}

// Helper for download URL
export function getDownloadUrl(id: number) {
  return buildUrl(api.analyses.download.path, { id });
}
