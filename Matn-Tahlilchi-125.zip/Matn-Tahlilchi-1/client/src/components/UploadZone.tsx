import { useCallback, useState } from "react";
import { UploadCloud, FileText, FileType, AlertCircle, Loader2 } from "lucide-react";
import { useUploadAnalysis } from "@/hooks/use-analyses";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";

export function UploadZone() {
  const [isDragging, setIsDragging] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const uploadMutation = useUploadAnalysis();

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const processFile = async (file: File) => {
    if (!file) return;

    // Validate file type
    const validTypes = [
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "text/plain"
    ];

    if (!validTypes.includes(file.type)) {
      toast({
        title: "Noto'g'ri format",
        description: "Iltimos, DOCX yoki TXT fayl yuklang.",
        variant: "destructive",
      });
      return;
    }

    try {
      const result = await uploadMutation.mutateAsync(file);
      toast({
        title: "Muvaffaqiyatli yuklandi!",
        description: "Matn tahlili boshlandi.",
      });
      setLocation(`/analysis/${result.id}`);
    } catch (error: any) {
      // Extract the most relevant error message
      let errorMessage = "Faylni yuklashda muammo bo'ldi.";
      
      if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.message) {
        errorMessage = error.message;
      }

      toast({
        title: "Xatolik",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFile(e.dataTransfer.files[0]);
    }
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFile(e.target.files[0]);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`
          relative overflow-hidden rounded-3xl border-2 border-dashed transition-all duration-300
          ${isDragging 
            ? "border-primary bg-primary/5 scale-[1.02] shadow-xl shadow-primary/10" 
            : "border-slate-200 hover:border-primary/50 hover:bg-slate-50"
          }
          bg-white p-12 text-center group cursor-pointer
        `}
      >
        <input
          type="file"
          id="file-upload"
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
          onChange={handleFileSelect}
          accept=".txt,.docx"
          disabled={uploadMutation.isPending}
        />
        
        {uploadMutation.isPending ? (
          <div className="flex flex-col items-center justify-center py-8 animate-in">
            <div className="relative">
              <div className="absolute inset-0 bg-primary/20 blur-xl rounded-full animate-pulse" />
              <Loader2 className="w-16 h-16 text-primary animate-spin relative z-10" />
            </div>
            <h3 className="mt-6 text-xl font-bold text-slate-900">Tahlil qilinmoqda...</h3>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-4">
            <div className={`
              w-20 h-20 rounded-2xl bg-blue-50 flex items-center justify-center mb-6
              group-hover:scale-110 group-hover:bg-blue-100 transition-all duration-300
            `}>
              <UploadCloud className="w-10 h-10 text-primary" />
            </div>
            
            <h3 className="text-2xl font-display font-bold text-slate-900 mb-2">
              Faylni bu yerga tashlang
            </h3>
            <p className="text-muted-foreground mb-8 max-w-sm mx-auto">
              Yoki kompyuteringizdan tanlash uchun bosing.
            </p>

            <div className="flex items-center gap-4 text-sm font-medium text-slate-500 bg-slate-50 px-6 py-3 rounded-xl border border-slate-100">
              <span className="flex items-center gap-1.5">
                <FileType className="w-4 h-4" /> DOCX
              </span>
              <span className="w-1 h-1 rounded-full bg-slate-300" />
              <span className="flex items-center gap-1.5">
                <FileText className="w-4 h-4" /> TXT
              </span>
            </div>
          </div>
        )}
      </div>

      <div className="mt-8 flex items-start gap-3 p-4 bg-amber-50 rounded-xl border border-amber-100 text-amber-900/80 text-sm">
        <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <p>
          <strong>Eslatma:</strong> Katta hajmdagi fayllarni tahlil qilish biroz vaqt olishi mumkin. 
          Maksimal fayl hajmi 10MB.
        </p>
      </div>
    </div>
  );
}
