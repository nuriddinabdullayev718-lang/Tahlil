import React, { useMemo } from "react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface DiffViewerProps {
  original: string;
  corrected: string;
}

export function DiffViewer({ original, corrected }: DiffViewerProps) {
  const renderedContent = useMemo(() => {
    if (!corrected) return <span>{original}</span>;

    // Regex to find [[original|suggestion|reason|type]]
    // We use a capture group to keep the delimiters in the split result
    const parts = corrected.split(/(\[\[.*?\|.*?\|.*?\|.*?\]\])/g);
    
    return parts.map((part, index) => {
      if (part.startsWith('[[') && part.endsWith(']]')) {
        const innerContent = part.slice(2, -2);
        const [orig, sugg, reason, type] = innerContent.split('|');
        
        return (
          <TooltipProvider key={index}>
            <Tooltip>
              <TooltipTrigger asChild>
                <span className="relative inline-flex flex-wrap items-baseline gap-1 mx-0.5">
                  <span className="text-red-500 line-through decoration-red-400/50">{orig}</span>
                  <span className="text-green-600 font-bold bg-green-50 px-1 rounded border border-green-100">{sugg}</span>
                </span>
              </TooltipTrigger>
              <TooltipContent className="max-w-xs p-3 bg-white border border-slate-200 shadow-xl rounded-xl z-[9999]">
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                      type?.trim().toLowerCase() === 'spelling' ? 'bg-red-100 text-red-700' : 
                      type?.trim().toLowerCase() === 'grammar' ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'
                    }`}>
                      {type?.trim().toLowerCase() === 'spelling' ? 'Imlo' : type?.trim().toLowerCase() === 'grammar' ? 'Grammatika' : 'Uslub'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    <span className="font-semibold text-slate-900">Sabab:</span> {reason}
                  </p>
                </div>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        );
      }
      // Return regular text parts
      return <span key={index}>{part}</span>;
    });
  }, [corrected, original]);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 h-[600px]">
      {/* Left Column: Original Text */}
      <div className="flex flex-col h-full bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <h3 className="font-display font-semibold text-slate-900">Asl Matn</h3>
          <span className="text-xs font-medium px-2.5 py-1 bg-slate-200 text-slate-600 rounded-md">O'zgartirishsiz</span>
        </div>
        <div className="p-6 overflow-y-auto font-mono text-sm leading-relaxed text-slate-600 h-full whitespace-pre-wrap select-all">
          {original}
        </div>
      </div>

      {/* Right Column: Visual Analysis */}
      <div className="flex flex-col h-full bg-white rounded-2xl border border-primary/20 shadow-lg shadow-primary/5 overflow-hidden ring-1 ring-primary/20">
        <div className="px-6 py-4 bg-primary/5 border-b border-primary/10 flex items-center justify-between">
          <h3 className="font-display font-semibold text-primary">Vizual Tahlil</h3>
          <span className="text-xs font-medium px-2.5 py-1 bg-primary/10 text-primary rounded-md">To'liq matn + Xatolar</span>
        </div>
        <div className="p-6 overflow-y-auto font-mono text-sm leading-relaxed text-slate-800 h-full whitespace-pre-wrap">
          {renderedContent}
        </div>
      </div>
    </div>
  );
}
