import { useRoute, useLocation } from "wouter";
import { useAnalysis, getDownloadUrl } from "@/hooks/use-analyses";
import { Navbar } from "@/components/Navbar";
import { DiffViewer } from "@/components/DiffViewer";
import { Loader2, ArrowLeft, Download, RefreshCw, FileText } from "lucide-react";
import { motion } from "framer-motion";

export default function AnalysisResult() {
  const [, params] = useRoute("/analysis/:id");
  const [, setLocation] = useLocation();
  const id = params ? parseInt(params.id) : 0;
  
  const { data, isLoading, error } = useAnalysis(id);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50">
        <Navbar />
        <div className="flex flex-col items-center justify-center h-[calc(100vh-64px)]">
          <Loader2 className="w-12 h-12 text-primary animate-spin mb-4" />
          <h2 className="text-xl font-bold text-slate-900">Natijalar yuklanmoqda...</h2>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-slate-50">
        <Navbar />
        <div className="max-w-md mx-auto mt-20 text-center px-4">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <FileText className="w-8 h-8 text-red-600" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Fayl topilmadi</h2>
          <p className="text-slate-500 mb-8">
            So'ralgan tahlil natijalari mavjud emas yoki o'chirilgan bo'lishi mumkin.
          </p>
          <button 
            onClick={() => setLocation("/")}
            className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-xl text-white bg-primary hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Bosh sahifaga qaytish
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      <Navbar />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header Section */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
          <div>
            <button 
              onClick={() => setLocation("/")}
              className="inline-flex items-center text-sm font-medium text-slate-500 hover:text-primary mb-3 transition-colors group"
            >
              <ArrowLeft className="w-4 h-4 mr-1 group-hover:-translate-x-1 transition-transform" />
              Bosh sahifa
            </button>
            <h1 className="text-3xl font-display font-bold text-slate-900 flex items-center gap-3">
              Tahlil Natijasi
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                Yakunlandi
              </span>
            </h1>
            <p className="text-slate-500 mt-1 flex items-center gap-2">
              <FileText className="w-4 h-4" />
              {data.originalFileName}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => window.location.reload()}
              className="inline-flex items-center px-4 py-2.5 border border-slate-200 shadow-sm text-sm font-medium rounded-xl text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-colors"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Yangilash
            </button>
            <a
              href={getDownloadUrl(id)}
              className="inline-flex items-center px-6 py-2.5 border border-transparent text-sm font-medium rounded-xl shadow-lg shadow-primary/25 text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-all hover:-translate-y-0.5 active:translate-y-0"
            >
              <Download className="w-4 h-4 mr-2" />
              Natijani yuklab olish (DOCX/TXT)
            </a>
          </div>
        </div>

        {/* Results Area */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <DiffViewer 
            original={data.originalContent} 
            corrected={data.correctedContent} 
          />
        </motion.div>
      </main>
    </div>
  );
}
