## Packages
diff | Text difference calculation for side-by-side view
lucide-react | Icons (already in base but good to confirm usage)
framer-motion | Smooth animations for upload and results
clsx | Class name utility
tailwind-merge | Class name merging

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["'Inter'", "sans-serif"],
  display: ["'Outfit'", "sans-serif"],
  mono: ["'JetBrains Mono'", "monospace"],
}
